package com.bandbuilder.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Locale;
import java.util.ArrayList;
import org.json.JSONObject;

public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private PermissionRequest pendingPerm;
    private SpeechRecognizer speechRecognizer;
    private boolean speechListening = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#1E4FA3"));
        web = new WebView(this);
        setContentView(web);

        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setAllowFileAccess(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("app.local".equals(u.getHost())) {
                    String path = u.getPath();
                    if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
                    try {
                        InputStream is = getAssets().open(path.substring(1));
                        String mime = path.endsWith(".html") ? "text/html"
                                : path.endsWith(".js") ? "application/javascript"
                                : path.endsWith(".css") ? "text/css" : "application/octet-stream";
                        return new WebResourceResponse(mime, "UTF-8", is);
                    } catch (Exception e) {
                        return null;
                    }
                }
                return super.shouldInterceptRequest(v, req);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pendingPerm = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
                    }
                });
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.82f);
                tts.setPitch(1.0f);
            }
        });

        web.loadUrl("https://app.local/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean granted = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (code == 7 && pendingPerm != null) {
            if (granted) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        } else if (code == 8) {
            if (granted) startNativeSpeech();
            else Toast.makeText(this, "মাইক্রোফোন অনুমতি প্রয়োজন", Toast.LENGTH_SHORT).show();
        }
    }

    private void startNativeSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 8);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult("", "");
            Toast.makeText(this, "এই ডিভাইসে Speech Recognition service নেই", Toast.LENGTH_LONG).show();
            return;
        }
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    if (speechListening) handler.postDelayed(() -> launchSpeechIntent(), 350);
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                    if (!text.isEmpty()) sendSpeechResult(text, "");
                    if (speechListening) handler.postDelayed(() -> launchSpeechIntent(), 250);
                }
                @Override public void onPartialResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                    sendSpeechResult("", text);
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }
        speechListening = true;
        launchSpeechIntent();
    }

    private void launchSpeechIntent() {
        if (!speechListening || speechRecognizer == null) return;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { speechRecognizer.startListening(intent); }
        catch (Exception e) { if (speechListening) handler.postDelayed(() -> launchSpeechIntent(), 500); }
    }

    private void sendSpeechResult(String finalText, String interimText) {
        if (web == null) return;
        String js = "window.onNativeSpeechResult && window.onNativeSpeechResult(" + JSONObject.quote(finalText) + "," + JSONObject.quote(interimText) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void stopNativeSpeech() {
        speechListening = false;
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            try { speechRecognizer.stopListening(); speechRecognizer.cancel(); } catch (Exception ignored) { }
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onBack?window.onBack():false)", value -> {
            if (!"true".equals(value)) defaultBack();
        });
    }

    private void defaultBack() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        stopNativeSpeech();
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(() -> {
                if (tts != null && ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bb");
            });
        }

        @JavascriptInterface
        public void stopSpeak() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }

        @JavascriptInterface
        public void startSpeechRecognition() {
            runOnUiThread(() -> startNativeSpeech());
        }

        @JavascriptInterface
        public void stopSpeechRecognition() {
            runOnUiThread(() -> stopNativeSpeech());
        }


    }
}
