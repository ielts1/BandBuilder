import http from 'node:http';

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.5';
const APP_TOKEN = process.env.APP_ACCESS_TOKEN;
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 12;
const clients = new Map();

const json = (res, status, body) => {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-app-token',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(body));
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 100_000) {
        reject(new Error('Request too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function rateLimited(ip) {
  const now = Date.now();
  const item = clients.get(ip) || { start: now, count: 0 };
  if (now - item.start > WINDOW_MS) { item.start = now; item.count = 0; }
  item.count += 1;
  clients.set(ip, item);
  return item.count > MAX_REQUESTS;
}

function makePrompt(kind, payload) {
  const common = `You are a careful IELTS Academic practice examiner and English-language teacher. Give an estimated practice score, never claim it is an official IELTS result. Explain in clear Bengali, while keeping corrected English examples in English. Be fair, specific, and do not reward memorised or unnatural phrases. If evidence is insufficient, say so.\n\nReturn: (1) estimated overall band and criterion bands with brief evidence, (2) strengths, (3) the five highest-impact corrections with before/after examples, (4) a short improved sample appropriate to the learner's ideas, (5) three focused practice actions. Do not invent errors that are not present.`;
  if (kind === 'writing_task2') {
    return `${common}\n\nAssess IELTS Writing Task 2 using Task Response, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy. Check whether the response addresses every part of the question, has a clear position, and develops ideas. Word count: ${String(payload.essay || '').trim().split(/\s+/).filter(Boolean).length}.\nQUESTION: ${payload.question || '(not supplied)'}\nESSAY:\n${payload.essay}`;
  }
  if (kind === 'writing_task1') {
    return `${common}\n\nAssess IELTS Academic Writing Task 1 using Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy. Check overview, key features, comparisons, data accuracy, and whether the report avoids opinions. Chart type: ${payload.chart_type || 'unspecified'}.\nQUESTION/CHART: ${payload.question || '(not supplied)'}\nREPORT:\n${payload.essay}`;
  }
  if (kind === 'speaking') {
    return `${common}\n\nAssess an IELTS Speaking practice transcript for Fluency and Coherence, Lexical Resource, and Grammatical Range and Accuracy. Pronunciation cannot be reliably scored from a transcript; clearly mark pronunciation as not assessed. Do not infer pauses or intonation that are absent from the transcript. Give a cautious estimated range if transcript evidence is limited. Part: ${payload.part}. Topic: ${payload.topic || ''}.\nQUESTION: ${payload.question}\nTRANSCRIPT:\n${payload.transcript}`;
  }
  throw new Error('Unsupported assessment type');
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'GET' && url.pathname === '/health') return json(res, 200, { status: 'online' });
  if (req.method !== 'POST' || url.pathname !== '/api/assess') return json(res, 404, { error: 'Not found' });
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  if (rateLimited(ip)) return json(res, 429, { error: 'Too many requests. Please wait one minute.' });
  if (!API_KEY || !APP_TOKEN) return json(res, 503, { error: 'Server is not configured. Set OPENAI_API_KEY and APP_ACCESS_TOKEN.' });
  if (req.headers['x-app-token'] !== APP_TOKEN) return json(res, 401, { error: 'Invalid app access token.' });
  try {
    const { kind, payload } = await readBody(req);
    if (!payload || typeof payload !== 'object') return json(res, 400, { error: 'Invalid payload.' });
    const prompt = makePrompt(kind, payload);
    if (prompt.length > 24_000) return json(res, 413, { error: 'Text is too long. Please shorten it.' });
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: MODEL, instructions: 'You are BandBuilder, an IELTS practice examiner. Follow the assessment instructions in the user input. Keep feedback educational and honest.', input: prompt, max_output_tokens: 1800 })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const message = result?.error?.message || 'AI provider request failed.';
      return json(res, upstream.status >= 500 ? 502 : upstream.status, { error: message });
    }
    const feedback = result.output_text || (result.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('\n');
    if (!feedback) return json(res, 502, { error: 'The AI returned no text. Please try again.' });
    return json(res, 200, { feedback, model: MODEL });
  } catch (error) {
    return json(res, 400, { error: error.message || 'Request failed.' });
  }
});

server.listen(PORT, () => console.log(`BandBuilder AI backend listening on ${PORT}`));
