# BandBuilder AI Backend

This small Node.js 20+ service keeps the AI provider key on the server and exposes the assessment endpoint used by the Android app.

## Configure

1. Copy `.env.example` to `.env` on your server.
2. Set `OPENAI_API_KEY`, `OPENAI_MODEL`, and a long random `APP_ACCESS_TOKEN`.
3. Run with your hosting provider's environment-variable settings. Do not commit `.env`.
4. Deploy behind HTTPS. The Android app accepts HTTPS backend URLs only.
5. In BandBuilder, open **Online AI Settings**, enter the deployed base URL and the same app access token, then save.

Run locally for development:

```sh
cp .env.example .env  # then edit .env with your private values
npm start
```

The Android app calls `GET /health` and `POST /api/assess`.

## Security notes

- The OpenAI key is never included in the APK or browser storage.
- The endpoint checks a separate app access token and applies a basic per-IP rate limit.
- Add stronger user authentication, persistent rate limiting, request logging with privacy controls, and usage limits before a public release. CORS is not authentication.
- The app uses browser speech recognition to produce a transcript. The current examiner scores the transcript; it cannot reliably score accent, intonation, or pronunciation from text. A production audio examiner requires a separate audio transcription/analysis workflow.
