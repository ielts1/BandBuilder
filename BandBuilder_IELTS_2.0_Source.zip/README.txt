BandBuilder IELTS 2.0 — Android Studio project

এই আপডেটে যা আছে
- Writing Task 2: Introduction/Body/Conclusion আলাদা input নয়; একটি Essay box-এ সম্পূর্ণ লেখা।
- Writing Task 1: Line, Bar, Pie, Table, Process, Map এবং Mixed chart-এর আলাদা structure ও বাংলা ব্যাখ্যা।
- Online AI Examiner: Writing Task 1/2 এবং Speaking transcript মূল্যায়নের জন্য নিরাপদ backend integration।
- Speaking: Part 1/2/3 question bank, topic-wise browse এবং Android native speech-to-text।
- Vocabulary: Reading, Listening, Writing Task 1, Writing Task 2, Speaking—প্রতি skill-এর শব্দ, বাংলা উচ্চারণ, বাংলা অর্থ, synonym/paraphrase।
- Android Internet permission, native English speech recognition এবং TTS speed adjustment।

গুরুত্বপূর্ণ — AI চালু করার জন্য Backend Deploy আবশ্যক
অ্যাপের মধ্যে AI API key রাখা নিরাপদ নয়। তাই `backend/` ফোল্ডারে আলাদা Node.js server দেওয়া আছে।
1. Node.js 20+ server-এ `backend/` deploy করুন।
2. `.env.example` কপি করে `.env` বানিয়ে OPENAI_API_KEY, OPENAI_MODEL এবং APP_ACCESS_TOKEN দিন।
3. `npm start` চালান এবং server-এ HTTPS চালু করুন।
4. অ্যাপে Settings → Online AI Settings-এ HTTPS backend URL ও একই APP_ACCESS_TOKEN দিন।
5. তারপর Writing/Speaking-এ AI Examiner ব্যবহার করুন। API ব্যবহারে provider-এর খরচ/usage limit প্রযোজ্য হতে পারে।

Speaking-এর সতর্কতা
Android native speech recognition কথাকে transcript-এ রূপান্তর করে। AI transcript থেকে Fluency, Vocabulary ও Grammar-এর practice feedback দেয়। শুধু transcript দেখে উচ্চারণ, accent বা intonation নির্ভুলভাবে score করা সম্ভব নয়; সেগুলোর জন্য আলাদা audio-analysis pipeline প্রয়োজন। AI band score আনুমানিক, অফিসিয়াল IELTS ফল নয়।

Build
Android Studio-তে এই project folder Open করুন, Gradle sync করে APK build করুন। এই পরিবেশে Gradle/Android SDK না থাকায় APK build করা হয়নি; Java/Android compile ও real-device microphone test Android Studio/device-এ করতে হবে।

প্রশ্ন ব্যাংক
প্রশ্নগুলো IELTS practice-এর জন্য topic-wise original/common-style prompts। কোনো প্রশ্নই পরীক্ষায় নিশ্চিতভাবে আসবে—এমন নিশ্চয়তা নয়; নিয়মিত নতুন topic যোগ করা উচিত।
